import { test, expect } from '@fixtures';
import { CPH_NUMBER_DISPLAY } from '@domain/animals/constants/journey-options';
import type { AnimalsPages } from '@page-objects';

const saveAndExpectCphOnAddresses = async (animalsPages: AnimalsPages, cph: string) => {
  await animalsPages.cphNumber.saveAndContinue.click();
  await expect(animalsPages.addresses.heading).toBeVisible();
  await expect(animalsPages.addresses.cphNumberText).toHaveText(cph);
};

test.describe('CPH number page', { tag: '@duplicated-in-frontend' }, () => {
  test.beforeEach(async ({ animalsJourney }) => {
    await animalsJourney.toCphNumber();
  });

  test('renders the page controls', async ({ animalsPages }) => {
    await expect(animalsPages.cphNumber.heading).toBeVisible();
    await expect(animalsPages.cphNumber.county).toBeVisible();
    await expect(animalsPages.cphNumber.parish).toBeVisible();
    await expect(animalsPages.cphNumber.holding).toBeVisible();
    await expect(animalsPages.cphNumber.saveAndContinue).toBeVisible();
  });

  test('leaves the CPH number empty on load', async ({ animalsPages }) => {
    await expect(animalsPages.cphNumber.county).toHaveValue('');
    await expect(animalsPages.cphNumber.parish).toHaveValue('');
    await expect(animalsPages.cphNumber.holding).toHaveValue('');
  });

  test('saves a valid CPH number and shows it on Consignment addresses', async ({ animalsPages }) => {
    await animalsPages.cphNumber.fillCphNumber();

    await saveAndExpectCphOnAddresses(animalsPages, CPH_NUMBER_DISPLAY);
  });

  test('saves the page blank and returns to Consignment addresses with the number not yet added', async ({ animalsPages }) => {
    await animalsPages.cphNumber.saveAndContinue.click();

    await expect(animalsPages.addresses.heading).toBeVisible();
    await expect(animalsPages.addresses.addCph).toBeVisible();
  });

  test('opens the help to its APHA-and-GOV.UK paragraph and the holding-details link, and gives the hint with no punctuation', async ({
    animalsPages,
  }) => {
    await animalsPages.cphNumber.helpSummary.click();

    await expect(animalsPages.cphNumber.helpWhereToFind).toBeVisible();
    await expect(animalsPages.cphNumber.holdingDetailsLink).toHaveAttribute(
      'href',
      'https://www.gov.uk/guidance/get-a-county-parish-holding-cph-number',
    );
    await expect(animalsPages.cphNumber.hint).toBeVisible();
  });

  test('keeps all nine digits typed straight through the county box and saves them', async ({ animalsPages }) => {
    const { county } = animalsPages.cphNumber;

    await county.click();
    await county.pressSequentially('123456789');
    await expect(county).toHaveValue('123456789');
    await expect(county).toBeFocused();

    await saveAndExpectCphOnAddresses(animalsPages, CPH_NUMBER_DISPLAY);
  });
});

test.describe('CPH number page without JavaScript', { tag: '@duplicated-in-frontend' }, () => {
  test.use({ javaScriptEnabled: false });

  test.beforeEach(async ({ animalsJourney }) => {
    await animalsJourney.toCphNumber();
  });

  test('saves a whole number with slashes inserted into the county box and shows it in its slashed form', async ({ animalsPages }) => {
    await animalsPages.cphNumber.county.fill('12/345/6789');

    await saveAndExpectCphOnAddresses(animalsPages, CPH_NUMBER_DISPLAY);
  });
});
