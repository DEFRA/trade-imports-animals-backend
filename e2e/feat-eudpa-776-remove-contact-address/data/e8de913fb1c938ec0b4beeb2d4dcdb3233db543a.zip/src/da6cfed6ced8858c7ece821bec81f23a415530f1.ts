import { MANDATORY_ANSWERS, type NotificationAnswers } from '@domain/animals/constants/journey-options';
import { MANDATORY_COMMODITY_LINES } from '@domain/animals/constants/journey-commodity-line-answers';
import { commodityLines } from '@domain/animals/constants/commodity-lines';
import { AnimalsAddressesPage } from '@page-objects/animals/addresses-page';

import { test, expect } from '@fixtures';

const CAT_ANSWERS: NotificationAnswers = {
  ...MANDATORY_ANSWERS,
  commodityLines: [MANDATORY_COMMODITY_LINES.domesticCat],
};

test.describe('Permanent address page', { tag: '@duplicated-in-frontend' }, () => {
  test('A cat consignment walked from the consignment addresses page through a hand-entered save, back to the consignment addresses page', async ({
    animalsJourney,
    animalsPages,
  }) => {
    await animalsJourney.toRolesAndAddresses(CAT_ANSWERS, () => animalsJourney.answerAnimalIdentification(CAT_ANSWERS));

    await expect(animalsPages.addresses.permanentAddressSection).toBeVisible();
    await expect(animalsPages.addresses.addPermanentAddress).toBeVisible();

    await animalsJourney.openPermanentAddress();

    const { permanentAddress: address } = MANDATORY_COMMODITY_LINES.domesticCat;
    const card = animalsPages.permanentAddress.card(commodityLines.domesticCat, 1);
    await expect(card).toBeVisible();
    await animalsPages.permanentAddress.selectNewAddress(card);
    await animalsPages.permanentAddress.fillNewAddress(address, card);
    await animalsPages.permanentAddress.saveAndContinue.click();

    await expect(animalsPages.addresses.heading).toBeVisible();
    await expect(animalsPages.addresses.permanentAddressText).toHaveText(
      AnimalsAddressesPage.expectedAddressText({
        name: address.nameOrOrganisationName,
        addressLine1: address.addressLine1,
        townOrCity: address.townOrCity,
        postcode: address.postcode,
        country: 'United Kingdom',
      }),
      { useInnerText: true },
    );

    await animalsPages.addresses.changePermanentAddress.click();
    await expect(animalsPages.permanentAddress.heading).toBeVisible();
    const reopenedCard = animalsPages.permanentAddress.card(commodityLines.domesticCat, 1);
    await expect(reopenedCard.getByRole('radio', { name: 'Enter a new address' })).toBeChecked();
    await expect(reopenedCard.getByLabel('Name or organisation name', { exact: true })).toHaveValue(address.nameOrOrganisationName);
  });

  test('A cat consignment submits once its permanent address is answered', async ({ animalsJourney, animalsPages }) => {
    await animalsJourney.submitNotification(CAT_ANSWERS);

    await expect(animalsPages.confirmation.heading).toBeVisible();
  });

  test('A cattle consignment offers no permanent address link, and opening the page directly lands on the consignment addresses page', async ({
    animalsJourney,
    animalsPages,
  }) => {
    await animalsJourney.toRolesAndAddresses();

    await expect(animalsPages.addresses.heading).toBeVisible();
    await expect(animalsPages.addresses.permanentAddressSection).toHaveCount(0);

    const referenceNumber = animalsPages.overview.referenceNumberFromUrl();
    await animalsPages.permanentAddress.open(referenceNumber);

    await expect(animalsPages.addresses.heading).toBeVisible();
  });

  test('refuses a blank new address with HTTP 400, names the animal in the summary while the field message stays plain, and the consignment addresses page still offers to add one afterwards', async ({
    animalsJourney,
    animalsPages,
    journeyContext,
    pages,
  }) => {
    await animalsJourney.toPermanentAddress(CAT_ANSWERS);
    const referenceNumber = journeyContext.referenceNumber;

    const card = animalsPages.permanentAddress.card(commodityLines.domesticCat, 1);
    await animalsPages.permanentAddress.selectNewAddress(card);

    const status = await animalsPages.permanentAddress.saveAndReadStatus(referenceNumber);

    expect(status).toBe(400);
    await expect(pages.page).toHaveTitle(/^Error: /);
    await expect(animalsPages.permanentAddress.errorSummaryLink('Enter a name or organisation name for Felis catus 1')).toBeVisible();
    const fieldError = await animalsPages.permanentAddress.fieldErrorMessage(card, 'Name or organisation name');
    await expect(fieldError).toHaveText('Error: Enter a name or organisation name');
    await expect(card.getByRole('radio', { name: 'Enter a new address' })).toBeChecked();

    await animalsPages.permanentAddress.linkBack.click();

    await expect(animalsPages.addresses.heading).toBeVisible();
    await expect(animalsPages.addresses.addPermanentAddress).toBeVisible();
  });

  test("shows the first cat's hand-entered permanent address unchanged after the line's second cat is saved on Identification details", async ({
    animalsJourney,
    animalsPages,
  }) => {
    const catLine = { ...MANDATORY_COMMODITY_LINES.domesticCat, noOfAnimals: 2 };
    const answers: NotificationAnswers = { ...MANDATORY_ANSWERS, commodityLines: [catLine] };
    const catCard = animalsPages.animalIdentification.speciesCard(commodityLines.domesticCat);

    await animalsJourney.toRolesAndAddresses(answers, async () => {
      await animalsPages.overview.task('Identification details').click();
      await animalsJourney.saveAnimalIdentifiers(catCard, catLine);
      await animalsPages.animalIdentification.saveAndReturnToOverview.click();
      await expect(animalsPages.overview.heading).toBeVisible();
    });

    await animalsJourney.answerPermanentAddresses([catLine]);
    await expect(animalsPages.addresses.heading).toBeVisible();

    await animalsJourney.openCurrentOverview();
    await animalsPages.overview.task('Identification details').click();
    await animalsJourney.saveAnimalIdentifiers(catCard, catLine);
    await animalsPages.animalIdentification.saveAndReturnToOverview.click();
    await expect(animalsPages.overview.heading).toBeVisible();

    await animalsPages.overview.task('Roles and addresses').click();
    await expect(animalsPages.addresses.heading).toBeVisible();
    await animalsJourney.openPermanentAddress();

    const reopenedFirstCatCard = animalsPages.permanentAddress.card(commodityLines.domesticCat, 1);
    await expect(reopenedFirstCatCard.getByRole('radio', { name: 'Enter a new address' })).toBeChecked();
    await expect(reopenedFirstCatCard.getByLabel('Name or organisation name', { exact: true })).toHaveValue(
      catLine.permanentAddress.nameOrOrganisationName,
    );
  });
});
